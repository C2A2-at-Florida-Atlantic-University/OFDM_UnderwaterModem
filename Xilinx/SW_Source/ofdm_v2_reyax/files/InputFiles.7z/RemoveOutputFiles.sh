#!/bin/bash

rm Rx* InputFiles.tar.xz *7z *.tar.bz2 ChannelEstimate1.txt TxFreqData1.txt TxIfftSamples1.txt TxIfftSamplesInt1.txt OfdmInfo1.txt
